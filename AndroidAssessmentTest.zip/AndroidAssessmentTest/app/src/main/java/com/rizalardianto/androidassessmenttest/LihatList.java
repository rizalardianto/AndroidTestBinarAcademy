package com.rizalardianto.androidassessmenttest;

import android.database.Cursor;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

/**
 * Created by rizal ardianto on 2017-12-09.
 */

public class LihatList extends AppCompatActivity {

    DatabaseHelper dbSQLITE;
    ArrayList<User> userlist;
    ListView listView;
    User user;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.view_content_layout);

        dbSQLITE = new DatabaseHelper(this);

        userlist = new ArrayList<>();
        Cursor data = dbSQLITE.getListContents();
        int numRows = data.getCount();

        if(numRows == 0){
            Toast.makeText(LihatList.this,"The Database is empty  :(.",Toast.LENGTH_LONG).show();
        }else{
            int i=0;
            while(data.moveToNext()){
                user = new User(data.getString(1),data.getString(2),data.getString(3),data.getString(4));
                userlist.add(i,user);
                System.out.println(data.getString(1)+" "+data.getString(2)+" "+data.getString(3)+" "+data.getString(4));
                System.out.println(userlist.get(i).getNama());
                i++;

            }
            FourColumn_ListAdapter adapter =  new FourColumn_ListAdapter(this,R.layout.list_adapter_view, userlist);
            listView = (ListView) findViewById(R.id.listview);
            listView.setAdapter(adapter);
        }

    }
}

package com.rizalardianto.androidassessmenttest;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Layout;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    EditText editBanyakBarang, editPemasok;
    TextView teksTanggal,editTanggal;
    Spinner spinner;
    Button btnAdd,btnView;
    Calendar mCurrentDate;
    int tgl, bulan, tahun;
    DatabaseHelper dbSQLITE;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        spinner = (Spinner) findViewById(R.id.spinner);
        editBanyakBarang = (EditText)findViewById(R.id.editBanyakBarang);
        editPemasok = (EditText) findViewById(R.id.editPemasok);
        teksTanggal = (TextView) findViewById(R.id.teksTanggal);
        editTanggal = (TextView) findViewById(R.id.editTanggal);

        btnAdd = (Button) findViewById(R.id.btnAdd);
        btnView = (Button) findViewById(R.id.btnView);

        dbSQLITE = new DatabaseHelper(this);

        btnView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, LihatList.class);
                startActivity(intent);
            }
        });

        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String fNama = spinner.getSelectedItem().toString();
                String lBanyakBarang = editBanyakBarang.getText().toString();
                String fPemasok = editPemasok.getText().toString();
                String lTanggal = editTanggal.getText().toString();

                if(fNama.length() != 0 && lBanyakBarang.length() != 0 && fPemasok.length() != 0 && lTanggal.length() !=0){
                    AddData(fNama,lBanyakBarang, fPemasok, lTanggal);
                    spinner.getSelectedItem().toString();
                    editBanyakBarang.setText("");
                    editPemasok.setText("");
//                    editTanggal.setText("");
                }else{
                    Toast.makeText(MainActivity.this,"You must put something in the text field!",Toast.LENGTH_LONG).show();
                }
            }
        });

        mCurrentDate = Calendar.getInstance();
        tgl = mCurrentDate.get(Calendar.DAY_OF_MONTH);
        bulan = mCurrentDate.get(Calendar.MONTH);
        tahun = mCurrentDate.get(Calendar.YEAR);

        bulan = bulan+1;

        editTanggal.setText(tgl+"/"+bulan+"/"+tahun);
        editTanggal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DatePickerDialog datePickerDialog = new DatePickerDialog(MainActivity.this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int tahun, int monthOfYear, int dayOfMonth) {
                        monthOfYear = monthOfYear+1;
                        editTanggal.setText(dayOfMonth+"/"+monthOfYear+"/"+tahun);

                    }
                },tahun,bulan,tgl);
                datePickerDialog.show();
            }
        });


        List<String>list = new ArrayList<>();
        list.add("Thane");
        list.add("Yoyok");
        list.add("Lubu");
        list.add("Ilham");
        list.add("Rizal");

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item, list);

        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                String itemvalue = parent.getItemAtPosition(position).toString();
                Toast.makeText(MainActivity.this,"Selected: "+itemvalue,Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
    }

    public void AddData(String Nama,String BanyakBarang, String Pemasok, String Tanggal){
        boolean insertData = dbSQLITE.addData(Nama,BanyakBarang,Pemasok, Tanggal);

        if(insertData==true){
            Toast.makeText(MainActivity.this,"Successfully Entered Data!",Toast.LENGTH_LONG).show();
        }else{
            Toast.makeText(MainActivity.this,"Something went wrong :(.",Toast.LENGTH_LONG).show();
        }
    }
}

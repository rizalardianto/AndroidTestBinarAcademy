package com.rizalardianto.androidassessmenttest;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by rizal ardianto on 2017-12-09.
 */

public class FourColumn_ListAdapter extends ArrayAdapter<User> {

    private LayoutInflater mInflater;
    private ArrayList<User> users;
    private int mViewResourceId;

    public FourColumn_ListAdapter(Context context, int textViewResourceId, ArrayList<User> users) {
        super(context, textViewResourceId, users);
        this.users = users;
        mInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        mViewResourceId = textViewResourceId;
    }
    public View getView(int position, View convertView, ViewGroup parent) {
        convertView = mInflater.inflate(mViewResourceId, null);

        User user = users.get(position);

        if (user != null) {
            TextView nama = (TextView) convertView.findViewById(R.id.colNama);
            TextView banyakbarang = (TextView) convertView.findViewById(R.id.colBanyakBarang);
            TextView pemasok = (TextView) convertView.findViewById(R.id.colPemasok);
            TextView tanggal = (TextView) convertView.findViewById(R.id.colTanggal);

            if (nama != null) {
                nama.setText(user.getNama());
            }
            if (banyakbarang != null) {
                banyakbarang.setText((user.getBanyakBarang()));
            }
            if (pemasok != null) {
                pemasok.setText((user.getPemasok()));
            }
            if (tanggal != null) {
                tanggal.setText((user.getTanggal()));
            }
        }

        return convertView;
    }

}

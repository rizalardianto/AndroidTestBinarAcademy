package com.rizalardianto.androidassessmenttest;

/**
 * Created by rizal ardianto on 2017-12-09.
 */

public class User {
    private String Nama, BanyakBarang, Pemasok, Tanggal;

    public User(String fNama,String lBanyakBarang, String fPemasok,String lTanggal){
        Nama = fNama;
        BanyakBarang = lBanyakBarang;
        Pemasok = fPemasok;
        Tanggal = lTanggal;
    }

    public String getNama() {
        return Nama;
    }

    public void setNama(String nama) {
        Nama = nama;
    }

    public String getBanyakBarang() {
        return BanyakBarang;
    }

    public void setBanyakBarang(String banyakBarang) {
        BanyakBarang = banyakBarang;
    }

    public String getPemasok() {
        return Pemasok;
    }

    public void setPemasok(String pemasok) {
        Pemasok = pemasok;
    }

    public String getTanggal() {
        return Tanggal;
    }

    public void setTanggal(String tanggal) {
        Tanggal = tanggal;
    }
}
